#include<iostream>
#include<cstdio>
#include<cstring>
#include<stdlib.h>
#include<algorithm>
//#include<omp.h>
#include <ctime>
#include"gmp.h"
#pragma warning(disable:4996)
#pragma comment(linker, "/STACK:102400000,102400000")
using namespace std;
clock_t start, finish;
const int Maxlen = 1000;//�ӷ�����󳤶�
const int Maxlenf = (Maxlen * Maxlen + Maxlen) / 2;
const int N = 2000;//��Ⱥ��Ŀ
const int K = 450;//�ӽ���Ŀ
const int AGE = 1000;//�Ŵ�����
const int Bian = 10;//�������
double d = 0.1; //probability of double the elements
double dd = 0.4;
mpz_t one, two, three, four;
struct AdditionChain
{
	mpz_t st[Maxlen];
	int len;
}ac[N];

struct Addition
{
	mpz_t st;
	int first, second;
}add[Maxlenf];

inline bool cmp(const AdditionChain &a, const AdditionChain &b)
{
	return a.len < b.len;
}

inline bool cmp1(const Addition &a, const Addition &b)
{
	int cp=mpz_cmp(a.st,b.st);
	if (!cp)return a.first < b.first;
	else if (cp < 0)return true;
	else return false;
}

mpz_t des;
mpz_t f;//���һ��
mpz_t twice;//�ӱ���Ľ��
mpz_t tmp; //��ʱ����1
mpz_t tmpx;//��ʱ����2
mpz_t cop[Maxlen];
mpz_t desa, desm;//Ŀ����+-5
inline bool Repair(AdditionChain &a, int len, int bb)
{
	bool leap = false;
	bool btwice = true;//���Լӱ���

	/*if (rep)
	{
		len = 0;
		int cmp = 0;
		mpz_set_ui(tmp, 0);
		for (int i = 0; i < len; i++)
		{
			cmp = mpz_cmp(a.st[i], des);
			if (!cmp)
			{
				leap = true;
				break;
			}
			else if (cmp > 0)break;
			else
			{
				if (i == 0 || mpz_cmp(a.st[i], tmp))
				{
					mpz_set(cop[len++], a.st[i]);
					mpz_set(tmp, a.st[i]);
				}
			}
		}
	}
	*/
	mpz_set(f, cop[len - 1]);
	//gmp_printf("%Zd\n", f);
	for (int j = 0; j < len; j++)
	{
		for (int k = j; k < len; k++)
		{
			mpz_add(tmp, cop[j], cop[k]);
			//if (!mpz_cmp(tmp, des))
			if (mpz_cmp(tmp, desm) >= 0 && mpz_cmp(tmp, desa) <= 0)
			{
				leap = true;
				break;
			}
		}
		if (leap)break;
	}

	while (!leap)
	{
		if (bb == 1)
		{
			//if (len >= 100)break;
		}
		else if (bb == 2)
		{

		}
		else
		{
			//if (len >= 100)break;
		}

		if (btwice)
		{
			mpz_add(twice, f, f);
			int cmp = mpz_cmp(twice, des);
			if (cmp > 0)
			{
				btwice = false;
			}
			else;
		}
		double r = rand() / double(RAND_MAX), rr;
		int first, second;
		//set<mpz_t>::iterator iter = stt.end;
		//iter--;
		if (btwice && r < d)
		{
			mpz_add(twice, f, f);
			while (mpz_cmp(twice, des) < 0)
			{
				//gmp_printf("%Zd\n", twice);
				mpz_set(cop[len++], twice);
				mpz_set(f, twice);
				mpz_add(twice, f, f);
			}
			btwice = false;
			for (int j = 0; j < len; j++)
			{
				for (int k = j; k < len; k++)
				{
					mpz_add(tmp, cop[j], cop[k]);
					if (!mpz_cmp(tmp, des))
					{
						leap = true;
						break;
					}
				}
				if (leap)break;
			}
		}
		else
		{
			int pos = 0;//��Ԫ�ز���λ��
			r = rand() / double(RAND_MAX);
			if (btwice)
			{
				if (r < dd)
				{
					mpz_add(tmp, f, f);
					mpz_set(cop[len++], tmp);
				}
				else 
				{
					rr = rand() % 2;
					if (rr)
					{
						first = rand() % len;
						mpz_add(tmp, f, cop[first]);
						mpz_set(cop[len++], tmp);
					}
					else 
					{
						rr = rand() % 2;
						if (rr)
						{
							first = rand() % (len / 2);
							//second = rand() % (len / 2) + (len / 2);
							if (len % 2)second = rand() % (len / 2 + 1) + (len / 2);
							else second = rand() % (len / 2) + (len / 2);
						}
						else
						{
							first = rand() % len;
							//second = rand() % (len / 2) + (len / 2);
							second = rand() % len;
						}

						mpz_add(tmp, cop[first], cop[second]);
						if (mpz_cmp(tmp, f) > 0)mpz_set(cop[len++], tmp);
						//else continue;
						/*
						for (pos = len - 1; pos >= 0; pos--)
						{
							int cmp = mpz_cmp(tmp, cop[pos]);
							if (!cmp)break;
							if (cmp > 0)
							{
								for (int j = len - 1; j > pos; j--)
									mpz_set(cop[j + 1], cop[j]);
								mpz_set(cop[pos + 1], tmp);
								len++;
								break;
							}
						}*/
					}
				}
			}
			else
			{
				if (r < 0.5)
				{
					first = rand() % len;
					mpz_add(tmp, f, cop[first]);
					if (mpz_cmp(tmp, des) > 0)
					{
						bool b = false;
						while (!b)
						{
							first--;
							mpz_add(tmp, f, cop[first]);
							if (mpz_cmp(tmp, des) < 0)b = true;
						}
						//int pos = rand() % (first + 1);
						//mpz_add(tmp, f, cop[pos]);
					}
					mpz_set(cop[len++], tmp);
				}
				else
				{
					rr = rand() % 2;
					if (rr)
					{
						first = rand() % (len / 2);
						//second = rand() % (len / 2) + (len / 2);
						if (len % 2)second = rand() % (len / 2 + 1) + (len / 2);
						else second = rand() % (len / 2) + (len / 2);
					}
					else
					{
						first = rand() % len;
						//second = rand() % (len / 2) + (len / 2);
						second = rand() % len;
					}

					mpz_add(tmp, cop[first], cop[second]);
					if (mpz_cmp(tmp, des) > 0)
					{
						bool b = false;
						while (!b)
						{
							first--;
							mpz_add(tmp, f, cop[first]);
							if (mpz_cmp(tmp, des) < 0)b = true;
						}
						//int pos = rand() % (first + 1);
						//mpz_add(tmp, f, cop[pos]);
					}
					if (mpz_cmp(tmp, f) > 0)mpz_set(cop[len++], tmp);
					//else continue;
					/*
					for (pos = len - 1; pos >= 0; pos--)
					{
						int cmp = mpz_cmp(tmp, cop[pos]);
						if (!cmp)break;
						if (cmp > 0)
						{
							for (int j = len - 1; j > pos; j--)
								mpz_set(cop[j + 1], cop[j]);
							mpz_set(cop[pos + 1], tmp);
							len++;
							break;
						}
					}*/
				}
			}
			for (int j = 0; j < len; j++)
			{
				mpz_add(tmpx, tmp, cop[j]);
				//if (!mpz_cmp(tmpx, des))
				if (mpz_cmp(tmpx, desm) >= 0 && mpz_cmp(tmpx, desa) <= 0)
				{
					leap = true;
					break;
				}
			}
			if (mpz_cmp(tmp, f) > 0) mpz_set(f, tmp);
		}
	}
	if (leap)
	{
		for (int j = 0; j < len; j++)
		{
			mpz_set(a.st[j], cop[j]);
		}
		a.len = len;
		//cout << len << endl;
		/*
		mpz_t five;
		mpz_init(five);
		mpz_set_ui(five, 5);
		if (!mpz_cmp(five, cop[3]))cout << "yes" << endl;
		mpz_clear(five);
		*/
		return true;
	}
	else return false;
}

void Ginit()
{
	for (int i = 0; i < N; i++)
	{
		int len = 0;
		mpz_set(cop[len++], one);
		mpz_set(cop[len++], two);
		int r = rand() % 2;
		if (r) { mpz_set(cop[len++], three); }
		else { mpz_set(cop[len++], four); }
		bool succ = false;
		while (!succ)succ = Repair(ac[i], len, 0);
	}
}
inline int Gcross(const AdditionChain &g, const AdditionChain &h)
{
	int first = rand() % (min(g.len, h.len) - 4) + 4, len = 0, pos = 0, l;
	for (int i = 0; i < first; i++)mpz_set(cop[i], g.st[i]);
	/*
	len = r;
	for (int i = r; i < h.len; i++)
	{
		bool leap = false;
		for (int j = 0; j < i; j++)
		{
			for (int k = 0; k <= j; k++)
			{
				mpz_add(tmp, h.st[j], h.st[k]);
				if (!mpz_cmp(tmp, h.st[i]))
				{
					first = k;
					second = j;
					leap = true;
					break;
				}
			}
			if (leap)break;
		}
		mpz_add(tmp, cop[first], cop[second]);
		//if (mpz_cmp(tmp, des) > 0)continue;
		for (int k = len - 1; k >= 0; k--)
		{
			int cmp = mpz_cmp(tmp, cop[k]);
			if (cmp >= 0)
			{
				for (int j = len - 1; j > k; j--)
					mpz_set(cop[j + 1], cop[j]);
				mpz_set(cop[k + 1], tmp);
				len++;
				break;
			}
		}
	}

	l = 1;
	mpz_set(tmp, cop[0]);
	for (int i = 1; i < len; i++)
	{
		if (mpz_cmp(cop[i], des) >= 0)break;
		if (mpz_cmp(tmp, cop[i]))
		{
			mpz_set(cop[l++], cop[i]);
			mpz_set(tmp, cop[i]);
		}
	}
	*/
	for (int i = 0; i < first; i++)
	{
		for (int j = i; j < first; j++)
		{
			mpz_add(tmp, h.st[i], h.st[j]);
			mpz_set(add[len].st, tmp);
			add[len].first = i;
			add[len].second = j;
			len++;
		}
	}
	sort(add, add + len, cmp1);
	
	pos = first;
	l = pos;
	
	int intv = rand() % len;
	for (int i = 0; i < intv; i++)
	{
		//if (pos >= h.len)break;
		if (!mpz_cmp(add[i].st, h.st[pos]))
		{
			mpz_add(tmp, cop[add[i].first], cop[add[i].second]);
			if (mpz_cmp(tmp, des) > 0)continue;
			for (int k = l - 1; k >= 0; k--)
			{
				int cmp = mpz_cmp(tmp, cop[k]);
				if (!cmp)break;
				if (cmp > 0)
				{
					for (int j = l - 1; j > k; j--)
						mpz_set(cop[j + 1], cop[j]);
					mpz_set(cop[k + 1], tmp);
					l++;
					break;
				}
			}
			pos++;
		}
	}
	
	return l;
}
inline int Gviriation(AdditionChain &g)
{
	int r = rand() % (g.len - 1) + 2;
	for (int i = 0; i < r; i++)mpz_set(cop[i], g.st[i]);
	int b = rand() % 2;
	if (b)
	{
		mpz_add(tmp, cop[r - 1], cop[r - 2]);
		if (mpz_cmp(tmp, des) < 0)mpz_set(cop[r], tmp);
		else r--;
	}
	else
	{
		int bb = rand() % r;
		mpz_add(tmp, cop[r - 1], cop[bb]);
		if (mpz_cmp(tmp, des) < 0) mpz_set(cop[r], tmp);
		else r--;
	}
	return r + 1;
}
void Genetic()
{
	srand((unsigned)time(NULL));
	Ginit();

	for (int i = 0; i < AGE; i++)
	{
		//cout << i << endl;
		sort(ac, ac + N, cmp);
		cout << "��" << i << "������ֵ��" << ac[0].len << endl;

		if (i == AGE - 1)
		{
			for (int i = 0; i < 10; i++)
			{
				for (int j = 0; j < ac[i].len; j++)
				{
					gmp_printf("%Zd ", ac[i].st[j]);
				}
				cout << endl;
			}
			cout << ac[0].len << endl;
		}

		for (int j = K; j < N; j += 2)
		{
			int a, b;
			double r = rand() / double(RAND_MAX);
			if (r < 0.5)a = rand() % (K / 4);
			else a = rand() % K;

			r = rand() / double(RAND_MAX);
			if (r < 0.01)b = rand() % (N >> 1);
			else b = rand() % K;
			int l = Gcross(ac[a], ac[b]);
			//qsort(ac[j].st, ac[j].len, sizeof(mpz_t));
			//sort(ac[j].st, ac[j].st + ac[j].len, cmp2);
			bool succ = false;
			while (!succ)
			{
				succ = Repair(ac[j], l, 1);
			}

			l = Gcross(ac[b], ac[a]);
			//qsort(ac[j].st, ac[j].len, sizeof(mpz_t));
			//sort(ac[j].st, ac[j].st + ac[j].len, cmp2);
			succ = false;
			while (!succ)
			{
				succ = Repair(ac[j+1], l, 1);
			}
		}
		int t = Bian;//������Ŀ
		while (t--)
		{
			int j = rand() % (N - 10) + 10;
			int l = Gviriation(ac[j]);				
			bool succ = false;
			while (!succ)
			{
				succ = Repair(ac[j], l, 2);
			}
			//memory[j].h = h(memory[j].a);
		}
	}
}

//char s1[10005], s2[10005];
//char s[105] = "81641602938012912661409453120480006585163317488785048239081071356093810587";
//char s[105] = "17182318319";
//char s[105] = "17182219767";
//char s[105] = "10445360463908";
//char s[105] = "211108170305887";
//char s[105] = "115216741";
//char s[105] = "14143037";
//char s[105] = "191";
//char s[105] = "1073740801";
//char s[105] = "561244339503060392854092169337519117127434749673212635322543";
//char s[105] = "170141183460469231731687303715884105725";
//char s[105] = "13835058061724614656";
char s[105] = "255211775190703851000955237173238443091";
//char s[105] = "2434060229";
//char s[105] = "8670198031853";
//char s[105] = "8871063607019543";
int main()
{
	//freopen("r.txt", "r", stdin);
	//freopen("w.txt", "w", stdout);

	srand((unsigned)time(NULL));
	//while (scanf("%s", s) != EOF)
	//{
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < Maxlen; j++)
			mpz_init(ac[i].st[j]);
	}
	for (int j = 0; j < Maxlen; j++)mpz_init(cop[j]);
	for (int j = 0; j < Maxlenf; j++)mpz_init(add[j].st);

	double duration;
	start = clock();
	mpz_init(des);
	mpz_init(desa);
	mpz_init(desm);
	mpz_init(one);
	mpz_init(two);
	mpz_init(three);
	mpz_init(four);
	mpz_init(f);
	mpz_init(twice);
	mpz_init(tmp);
	mpz_init(tmpx);
	mpz_init_set_str(des, s, 10);
	mpz_sub_ui(desm, des, 5);
	mpz_add_ui(desa, des, 5);
	mpz_set_ui(one, 1);
	mpz_set_ui(two, 2);
	mpz_set_ui(three, 3);
	mpz_set_ui(four, 4);

	for (int i = 0; i < 10; i++)Genetic();
	
	/*
	char st[1000];
	mpz_t m[1000];
	for (int i = 0; i < 1000; i++)mpz_init(m[i]);
	int num = 0;
	while (scanf("%s", st) != EOF)
	{
		mpz_init_set_str(m[num++], st, 10);
	}

	bool judge = false;
	for (int i = 0; i < num; i++)
	{
		for (int j = 0; j <= i; j++)
		{
			mpz_add(tmpx, m[i], m[j]);
			mpz_add(tmpx, tmpx, m[num - 1]);
			if (mpz_cmp(tmpx, desm) >= 0 && mpz_cmp(tmpx, desa) <= 0)
			{
				mpz_add(tmpx, m[num - 1], m[i]);
				mpz_set(m[num++], tmpx);
				mpz_add(tmpx, tmpx, m[j]);
				mpz_set(m[num++], tmpx);
				judge = true;
				break;
			}
		}
		if (judge)break;
	}

	if (!judge)cout << "error1" << endl;

	for (int i = 1; i < num; i++)
	{
		judge = false;
		for (int j = 0; j < i; j++)
		{
			for (int k = 0; k <= j; k++)
			{
				mpz_add(tmp, m[j], m[k]);
				if (!mpz_cmp(m[i], tmp))
				{
					judge = true;
					break;
				}
			}
			if (judge)break;
		}
		if (!judge)cout << "error2" << endl;
	}

	cout << num << endl;
	for (int k = 0; k < num; k++)gmp_printf("%Zd\n", m[k]);

	for (int i = 0; i < 1000; i++)mpz_clear(m[i]);
	*/
	finish = clock();
	duration = double(finish - start) / CLOCKS_PER_SEC;
	printf("Time used:%fms\n\n", 1000 * duration);

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < Maxlen; j++)
			mpz_clear(ac[i].st[j]);
	}
	for (int j = 0; j < Maxlen; j++)mpz_clear(cop[j]);
	for (int j = 0; j < Maxlenf; j++)mpz_clear(add[j].st);

	mpz_clear(des);
	mpz_clear(desa);
	mpz_clear(desm);
	mpz_clear(one);
	mpz_clear(two);
	mpz_clear(three);
	mpz_clear(four);
	//while (1);
	system("pause");
	return 0;
}
/*
int main()
{
freopen("r.txt", "r", stdin);
//freopen("w.txt", "w", stdout);

srand((unsigned)time(NULL));
//int t;
number ans;
//scanf("%d", &t);
while (scanf("%s", s) != EOF)
{
number aa;
clock_t start, finish;
double duration;
start = clock();
change(s, aa);
aa.print();
//if ((aa.a[1] & 1) == 0){ printf("Prime"); continue; }
ans = rho(aa);
if (larger(ans, aa) == 2)printf("is a prime\n");
else ans.print();
finish = clock();
duration = double(finish - start) / CLOCKS_PER_SEC;
printf("Time used:%fms\n\n", 1000 * duration);
}
/*
for (int i = 1051; i <= 20000; i += 2)
{
number now = i;
if (Miller_Rabin(now))
{
cout << i << "&&&" << endl;
a1 = pow0(3, i) + 1;
a2 = a1 - 2;
if (Miller_Rabin(a1 / 4) && Miller_Rabin(a2 / 2))
{
cout << i << endl;
}
}
}
while (scanf("%s%s", s1, s2) != EOF){
//cout << mm << endl;
change(s1, a1);
change(s2, a2);
//print(a1);
//print(a2);
gcd(a1, a2).print();
}
return 0;
}
*/